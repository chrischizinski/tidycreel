#' Create a creel survey design
#'
#' @description
#' Constructs a `creel_design` object from calendar data with tidy column
#' selection. This is the entry point for all creel survey analysis workflows.
#' The design object stores the survey structure (date, strata, optional site),
#' validates input data (Tier 1 validation), and serves as the foundation for
#' adding count data and estimating effort.
#'
#' @param calendar A data frame containing calendar data with date and strata
#'   columns. Must have at least one Date column and one character/factor column
#'   (validated via internal schema check).
#' @param date Tidy selector for the date column. Must select exactly one
#'   column of class Date. Accepts bare column names or tidyselect helpers
#'   (e.g., `starts_with("date")`).
#' @param strata Tidy selector for strata columns. Can select one or more
#'   columns of class character or factor. Accepts bare column names or
#'   tidyselect helpers (e.g., `c(day_type, season)` or `starts_with("day")`).
#' @param site Optional tidy selector for a site column. Must select exactly
#'   one column of class character or factor if provided. Use for multi-site
#'   surveys. Default is `NULL` (single-site survey).
#' @param design_type Character string specifying the survey design type.
#'   Default is `"instantaneous"`. Future versions will support `"roving"`,
#'   `"aerial"`, and `"bus_route"`.
#'
#' @return A `creel_design` S3 object (list) with components:
#'   \item{calendar}{The original calendar data frame}
#'   \item{date_col}{Character name of the date column}
#'   \item{strata_cols}{Character vector of strata column names}
#'   \item{site_col}{Character name of site column, or NULL}
#'   \item{design_type}{Character design type}
#'   \item{counts}{NULL (populated by `add_counts()` in future)}
#'   \item{survey}{NULL (populated internally during estimation)}
#'
#' @section Tier 1 Validation:
#' The constructor performs fail-fast validation:
#' - Date column is class Date (not character, numeric, POSIXct)
#' - Date column contains no NA values
#' - Strata columns are character or factor (not numeric, logical)
#' - Site column (if provided) is character or factor
#'
#' @examples
#' # Basic design with single stratum
#' calendar <- data.frame(
#'   date = as.Date(c("2024-06-01", "2024-06-02", "2024-06-03")),
#'   day_type = c("weekday", "weekend", "weekend")
#' )
#' design <- creel_design(calendar, date = date, strata = day_type)
#'
#' # Multiple strata
#' calendar <- data.frame(
#'   date = as.Date(c("2024-06-01", "2024-06-02")),
#'   day_type = c("weekday", "weekend"),
#'   season = c("summer", "summer")
#' )
#' design <- creel_design(calendar, date = date, strata = c(day_type, season))
#'
#' # With site column for multi-site survey
#' calendar <- data.frame(
#'   date = as.Date(c("2024-06-01", "2024-06-02")),
#'   day_type = c("weekday", "weekend"),
#'   lake = c("lake_a", "lake_b")
#' )
#' design <- creel_design(calendar, date = date, strata = day_type, site = lake)
#'
#' # Using tidyselect helpers
#' calendar <- data.frame(
#'   survey_date = as.Date(c("2024-06-01", "2024-06-02")),
#'   day_type = c("weekday", "weekend"),
#'   day_period = c("morning", "evening")
#' )
#' design <- creel_design(
#'   calendar,
#'   date = starts_with("survey"),
#'   strata = starts_with("day")
#' )
#'
#' @export
creel_design <- function(calendar,
                         date,
                         strata,
                         site = NULL,
                         design_type = "instantaneous") {
  # 1. Structural validation (Phase 1 validator)
  validate_calendar_schema(calendar) # nolint: object_usage_linter

  # 2. Resolve tidy selectors to column names
  date_col <- resolve_single_col(
    rlang::enquo(date),
    calendar,
    "date",
    rlang::caller_env()
  )

  strata_cols <- resolve_multi_cols(
    rlang::enquo(strata),
    calendar,
    "strata",
    rlang::caller_env()
  )

  site_col <- NULL
  site_quo <- rlang::enquo(site)
  if (!rlang::quo_is_null(site_quo)) {
    site_col <- resolve_single_col(
      site_quo,
      calendar,
      "site",
      rlang::caller_env()
    )
  }

  # 3. Construct and validate
  design <- new_creel_design(
    calendar    = calendar,
    date_col    = date_col,
    strata_cols = strata_cols,
    site_col    = site_col,
    design_type = design_type
  )
  validate_creel_design(design)
}

#' Low-level creel_design constructor
#'
#' Internal constructor that creates the creel_design structure with type
#' checking only. Does not perform semantic validation. Use [creel_design()]
#' for user-facing construction.
#'
#' @param calendar Data frame with calendar data
#' @param date_col Character name of date column
#' @param strata_cols Character vector of strata column names
#' @param site_col Character name of site column, or NULL
#' @param design_type Character design type
#'
#' @return A creel_design object (list with class attribute)
#'
#' @keywords internal
#' @noRd
new_creel_design <- function(calendar,
                             date_col,
                             strata_cols,
                             site_col = NULL,
                             design_type = "instantaneous") {
  stopifnot(is.data.frame(calendar))
  stopifnot(is.character(date_col), length(date_col) == 1)
  stopifnot(is.character(strata_cols), length(strata_cols) >= 1)
  stopifnot(is.null(site_col) || (is.character(site_col) && length(site_col) == 1))
  stopifnot(is.character(design_type), length(design_type) == 1)

  structure(
    list(
      calendar    = calendar,
      date_col    = date_col,
      strata_cols = strata_cols,
      site_col    = site_col,
      design_type = design_type,
      counts      = NULL,
      survey      = NULL
    ),
    class = "creel_design"
  )
}

#' Validate creel_design object (Tier 1)
#'
#' Performs semantic validation on a creel_design object. Checks that the
#' user-specified columns have appropriate types and values for creel survey
#' analysis.
#'
#' @param x A creel_design object
#'
#' @return Invisibly returns the input object on success. Aborts with
#'   informative cli error message on validation failure.
#'
#' @keywords internal
#' @noRd
validate_creel_design <- function(x) {
  cal <- x$calendar

  # Tier 1: Date column is actually Date class
  if (!inherits(cal[[x$date_col]], "Date")) {
    cli::cli_abort(c(
      "Column {.var {x$date_col}} must be of class {.cls Date}.",
      "x" = "Column {.var {x$date_col}} is {.cls {class(cal[[x$date_col]])[1]}}.",
      "i" = "Convert with {.code as.Date()}."
    ))
  }

  # Tier 1: Date column has no NA values
  if (anyNA(cal[[x$date_col]])) {
    cli::cli_abort(c(
      "Column {.var {x$date_col}} must not contain {.val NA} values.",
      "i" = "Remove or impute missing dates before creating a design."
    ))
  }

  # Tier 1: Strata columns exist and are character/factor
  for (col in x$strata_cols) {
    if (!is.character(cal[[col]]) && !is.factor(cal[[col]])) {
      cli::cli_abort(c(
        "Strata column {.var {col}} must be character or factor.",
        "x" = "Column {.var {col}} is {.cls {class(cal[[col]])[1]}}."
      ))
    }
  }

  # Tier 1: Site column (if provided) is character/factor
  if (!is.null(x$site_col)) {
    if (!is.character(cal[[x$site_col]]) && !is.factor(cal[[x$site_col]])) {
      cli::cli_abort(c(
        "Site column {.var {x$site_col}} must be character or factor.",
        "x" = "Column {.var {x$site_col}} is {.cls {class(cal[[x$site_col]])[1]}}."
      ))
    }
  }

  invisible(x)
}

#' Resolve single column from tidy selector
#'
#' Internal helper to resolve a tidy selector expression to exactly one column
#' name. Used for date and site parameters.
#'
#' @param expr Quosure containing the tidy selector expression
#' @param data Data frame to select from
#' @param arg_name Name of the argument (for error messages)
#' @param error_call Calling environment for error reporting
#'
#' @return Character scalar with the selected column name
#'
#' @keywords internal
#' @noRd
resolve_single_col <- function(expr, data, arg_name, error_call = rlang::caller_env()) {
  loc <- tidyselect::eval_select(
    expr,
    data = data,
    allow_rename = FALSE,
    allow_empty = FALSE,
    error_call = error_call
  )
  if (length(loc) != 1) {
    cli::cli_abort(
      "{.arg {arg_name}} must select exactly one column, not {length(loc)}.",
      call = error_call
    )
  }
  names(loc)
}

#' Resolve multiple columns from tidy selector
#'
#' Internal helper to resolve a tidy selector expression to one or more column
#' names. Used for strata parameter.
#'
#' @param expr Quosure containing the tidy selector expression
#' @param data Data frame to select from
#' @param arg_name Name of the argument (for error messages)
#' @param error_call Calling environment for error reporting
#'
#' @return Character vector with selected column names
#'
#' @keywords internal
#' @noRd
resolve_multi_cols <- function(expr, data, arg_name, error_call = rlang::caller_env()) {
  loc <- tidyselect::eval_select(
    expr,
    data = data,
    allow_rename = FALSE,
    allow_empty = FALSE,
    error_call = error_call
  )
  names(loc)
}

#' Attach count data to a creel design
#'
#' @description
#' Attaches instantaneous count data to a creel_design object and constructs
#' the internal survey design object eagerly. This is the core of the survey
#' bridge layer - translating domain vocabulary (creel counts) into statistical
#' machinery (survey::svydesign). Eager construction catches design errors at
#' add_counts() time when users have context about what data they are adding.
#'
#' @param design A creel_design object (created with [creel_design()])
#' @param counts Data frame containing count data. Must have:
#'   - A Date column matching the design's date_col
#'   - All strata columns from the design's strata_cols
#'   - At least one numeric column (the count variable)
#'   - A PSU column (specified via psu argument, defaults to date_col)
#' @param psu Character string naming the PSU (Primary Sampling Unit) column
#'   in the count data. Defaults to NULL, which uses the design's date_col as
#'   the PSU (day-as-PSU is the most common creel design). For other designs,
#'   specify the PSU column explicitly (e.g., "site_day" for day-site PSUs).
#' @param allow_invalid Logical flag for validation behavior. If FALSE (default),
#'   validation failures abort with detailed error messages. If TRUE, validation
#'   failures generate warnings and attach counts anyway (use with caution).
#'
#' @return A new creel_design object (list) with components:
#'   \item{calendar}{Original calendar data frame}
#'   \item{date_col}{Character name of date column}
#'   \item{strata_cols}{Character vector of strata column names}
#'   \item{site_col}{Character name of site column, or NULL}
#'   \item{design_type}{Character design type}
#'   \item{counts}{The count data frame (newly attached)}
#'   \item{psu_col}{Character name of PSU column}
#'   \item{survey}{Internal survey.design2 object (newly constructed)}
#'   \item{validation}{creel_validation object with Tier 1 results}
#'
#' @section Immutability:
#' add_counts() follows functional programming patterns and returns a new
#' creel_design object. The original design object is not modified. This
#' prevents accidental data loss and makes the workflow explicit:
#' `design2 <- add_counts(design, counts)` not `add_counts(design, counts)`
#'
#' @section Validation:
#' add_counts() performs Tier 1 validation:
#' - Count data schema (Date column, numeric column) via validate_count_schema()
#' - Design column presence (date_col, strata_cols, PSU in count data)
#' - No NA values in design-critical columns (date, strata, PSU)
#' - Survey construction (catches lonely PSU errors, stratification issues)
#'
#' @section PSU Specification:
#' Per user decision (clarified 2026-02-08), PSU is specified only in add_counts(),
#' not in creel_design() constructor. PSU is only meaningful when count data is
#' present, making add_counts() the correct abstraction boundary. This design
#' allows the same creel_design calendar to be used with different PSU structures.
#'
#' @examples
#' # Basic usage - day as PSU (default)
#' calendar <- data.frame(
#'   date = as.Date(c("2024-06-01", "2024-06-02", "2024-06-03", "2024-06-04")),
#'   day_type = c("weekday", "weekday", "weekend", "weekend")
#' )
#' design <- creel_design(calendar, date = date, strata = day_type)
#'
#' counts <- data.frame(
#'   date = as.Date(c("2024-06-01", "2024-06-02", "2024-06-03", "2024-06-04")),
#'   day_type = c("weekday", "weekday", "weekend", "weekend"),
#'   count = c(15, 23, 45, 52)
#' )
#'
#' design_with_counts <- add_counts(design, counts)
#' print(design_with_counts)
#'
#' # Custom PSU column
#' counts_with_site_psu <- data.frame(
#'   date = as.Date(c("2024-06-01", "2024-06-02", "2024-06-03", "2024-06-04")),
#'   day_type = c("weekday", "weekday", "weekend", "weekend"),
#'   site_day = paste0("site_", 1:4),
#'   count = c(15, 23, 45, 52)
#' )
#'
#' design2 <- add_counts(design, counts_with_site_psu, psu = "site_day")
#'
#' @export
add_counts <- function(design, counts, psu = NULL, allow_invalid = FALSE) {
  # Validate design is creel_design
  if (!inherits(design, "creel_design")) {
    cli::cli_abort(c(
      "{.arg design} must be a {.cls creel_design} object.",
      "x" = "{.arg design} is {.cls {class(design)[1]}}.",
      "i" = "Create a design with {.fn creel_design}."
    ))
  }

  # Check counts not already attached
  if (!is.null(design$counts)) {
    cli::cli_abort(c(
      "Counts already attached to design.",
      "x" = "The design object already has count data in the {.field $counts} slot.",
      "i" = "Create a new design with {.fn creel_design} to attach different counts.",
      "i" = "Use immutable workflow: {.code design2 <- add_counts(design, counts)}"
    ))
  }

  # Validate count data schema (Date column, numeric column)
  validate_count_schema(counts) # nolint: object_usage_linter

  # Set PSU column (default to date_col for day-as-PSU)
  if (is.null(psu)) {
    psu <- design$date_col
  }

  # Validate counts structure (Tier 1)
  validation <- validate_counts_tier1(counts, design, psu, allow_invalid) # nolint: object_usage_linter

  # Copy design and add counts + PSU
  new_design <- design
  new_design$counts <- counts
  new_design$psu_col <- psu

  # Construct survey design eagerly
  new_design$survey <- construct_survey_design(new_design) # nolint: object_usage_linter

  # Store validation results
  new_design$validation <- validation

  # Preserve class
  class(new_design) <- "creel_design"

  new_design
}

#' Format a creel_design object
#'
#' @param x A creel_design object
#' @param ... Additional arguments (ignored)
#'
#' @return A character vector with the formatted output
#'
#' @export
format.creel_design <- function(x, ...) {
  cli::cli_format_method({
    cli::cli_h1("Creel Survey Design")
    cli::cli_text("Type: {.val {x$design_type}}")
    cli::cli_text("Date column: {.field {x$date_col}}")
    cli::cli_text("Strata: {.field {paste(x$strata_cols, collapse = ', ')}}")
    if (!is.null(x$site_col)) {
      cli::cli_text("Site column: {.field {x$site_col}}")
    }

    n_days <- nrow(x$calendar) # nolint: object_usage_linter
    date_range <- range(x$calendar[[x$date_col]]) # nolint: object_usage_linter
    cli::cli_text("Calendar: {.val {n_days}} day{?s} ({date_range[1]} to {date_range[2]})")

    # Strata summary
    for (col in x$strata_cols) {
      levels <- unique(x$calendar[[col]]) # nolint: object_usage_linter
      cli::cli_text("  {.field {col}}: {.val {length(levels)}} level{?s}")
    }

    has_counts <- !is.null(x$counts) # nolint: object_usage_linter
    has_survey <- !is.null(x$survey) # nolint: object_usage_linter
    if (has_counts) {
      n_counts <- nrow(x$counts) # nolint: object_usage_linter
      psu_col <- x$psu_col # nolint: object_usage_linter
      cli::cli_text("Counts: {.val {n_counts}} observation{?s}")
      cli::cli_text("  PSU column: {.field {psu_col}}")
      if (has_survey) {
        survey_class <- class(x$survey)[1] # nolint: object_usage_linter
        cli::cli_text("  Survey: {.cls {survey_class}} (constructed)")
      }
    } else {
      cli::cli_text("Counts: {.val none}")
    }
  })
}

#' Print a creel_design object
#'
#' @param x A creel_design object
#' @param ... Additional arguments passed to [format.creel_design()]
#'
#' @return Invisibly returns the input object
#'
#' @export
print.creel_design <- function(x, ...) {
  cat(format(x, ...), sep = "\n")
  invisible(x)
}

#' Summarize a creel_design object
#'
#' @param object A creel_design object
#' @param ... Additional arguments passed to [print.creel_design()]
#'
#' @return Invisibly returns the input object
#'
#' @export
summary.creel_design <- function(object, ...) {
  print(object, ...)
  invisible(object)
}
